<!DOCTYPE html>
<html>
<html>
<link rel="stylesheet" type="text/css" href="Style/killme.css">
<?php
	$con = mysqli_connect("localhost","root","","swaptest"); //connect to database
	if (!$con) {
		die('Could not connect: ' . mysqli_connect_errno());
		echo "Connection to Server Failed.";
		exit(); //return error is connect fail
	}
?>
<head>
	<title>SMD</title>
		<div class="naviBar">
		<nav>
		<p>SMD</p>
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="bene.php">Beneficiaries</a></li>
			<li><a href="#">Contact Us</a></li>
			<li><a href="#">Profile</a>
				<ul>
					<li><a href="#">My Donations</a></li>
					<li><a href="customer_update.html">Update Information</a></li>
				</ul>
			</li>
			<li><a href="#">Administration</a>
				<ul>
					<li><a href="adminAdd.html">Insert Beneficiaries</a></li>
					<li><a href="adminUpdate.php">Update Beneficiaries</a></li>
					<li><a href="adminDelete.php">Delete Beneficiaries</a></li>
				</ul>
			</li>
		</ul>	
	</nav>
</div>
</head>
<body>
<div class="beneAddBox">
	<?php
		function check_bene($name) {
			if (!preg_match("/[\w][.,]*/", $name)) {
				return false;
			}
			else {
				return true;
			}
		}

		if (!check_bene($_POST["updateBeneName"])) {
				echo "Invalid Name or Description. Cannot contain symbols";
			}
			elseif (!check_bene($_POST["updateBeneDes"])) {
				echo "Invalid Description. Cannot contain symbols";
			}
			else {
				$beneID = $_POST["updateBene"];
				$beneName = $_POST["updateBeneName"];
				$beneDes = $_POST["updateBeneDes"];
				$sql="UPDATE bene SET bene_name='$beneName', bene_des='$beneDes' 
				WHERE bene_id='$beneID'";
			}
			if ($con->query($sql) === TRUE) {
			    echo "Updated record successfully";
			} else {
				echo "Make sure values are not empty.";
			    echo "Error: " . $sql . "<br>" . $con->error;
			    exit();
			}

			$con->close();
	?>
</div>
</body>
</html>