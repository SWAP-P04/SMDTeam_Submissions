<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="Style/killme.css">
<?php
	$con = mysqli_connect("localhost","root","","swaptest"); //connect to database
	if (!$con) {
		die('Could not connect: ' . mysqli_connect_errno());
		echo "Connection to Server Failed.";
		exit(); //return error is connect fail
	}
?>
<head>
	<title>SMDAdmin</title>
	<div class="naviBar">
		<nav>
		<p>SMD</p>
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="bene.php">Beneficiaries</a></li>
			<li><a href="#">Contact Us</a></li>
			<li><a href="#">Profile</a>
				<ul>
					<li><a href="#">My Donations</a></li>
					<li><a href="customer_update.html">Update Information</a></li>
				</ul>
			</li>
			<li><a href="#">Administration</a>
				<ul>
					<li><a href="adminAdd.html">Insert Beneficiaries</a></li>
					<li><a href="adminUpdate.php">Update Beneficiaries</a></li>
					<li><a href="adminDelete.php">Delete Beneficiaries</a></li>
				</ul>
			</li>
		</ul>	
	</nav>
</div>
</head>
<body>
<div class="beneAddBox">
	<h1>Delete Beneficiaries</h1>
	<form action="beneDelete.php" method="post">
		<?php
			$sql = "SELECT bene_id, bene_name, bene_des from bene";
			$result = $con->query($sql);

			$temp = 0;
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
				$id_array = $row["bene_id"];
				$name_array = $row["bene_name"];
				echo '
				<input type="radio" name="deleteBene" 
				value="'.$id_array.'">'.$name_array.'<br><br>
				';
				
				$temp++;
				}
			}
			else {
				exit();
				echo "0 results";
			}
			$con->close();
		?>
	<input type="submit">
	</form>
</div>
</body>
</html>