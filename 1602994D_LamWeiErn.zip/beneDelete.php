<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="Style/killme.css">
<?php
	$con = mysqli_connect("localhost","root","","swaptest"); //connect to database
	if (!$con) {
		die('Could not connect: ' . mysqli_connect_errno());
		echo "Connection to Server Failed.";
		exit(); //return error is connect fail
	}
?>
<head>
	<title>SMD</title>
		<div class="naviBar">
		<nav>
		<p>SMD</p>
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="bene.php">Beneficiaries</a></li>
			<li><a href="#">Contact Us</a></li>
			<li><a href="#">Profile</a>
				<ul>
					<li><a href="#">My Donations</a></li>
					<li><a href="customer_update.html">Update Information</a></li>
				</ul>
			</li>
			<li><a href="#">Administration</a>
				<ul>
					<li><a href="adminAdd.html">Insert Beneficiaries</a></li>
					<li><a href="adminUpdate.php">Update Beneficiaries</a></li>
					<li><a href="adminDelete.php">Delete Beneficiaries</a></li>
				</ul>
			</li>
		</ul>	
	</nav>
</div>
</head>
<body>
<div class="beneAddBox">
	<?php
		$beneID = $_POST["deleteBene"];
		$sql = "DELETE FROM bene WHERE bene_id='$beneID'";
		if ($con->query($sql) === TRUE) {
		    echo "Record deleted successfully";
		} else {
		    echo "Error deleting record: " . $con->error;
		}

		$con->close();
	?>
</div>
</body>
</html>